# Occultation Manager

SharpCap Occultation Manager streamlines your occultation observation workflow by automating event management and generating customizable SharpCap sequences. It downloads your announced observations from Occult Watcher Cloud and creates sequences tailored to your equipment and recording preferences. The sequences give you complete control over your recording setup, allowing you to automate as much or as little as you need.

## Key Features

**Event Management**
- Downloads personal observations from Occult Watcher Cloud
- Manages event list with filtering by date, location, and probability
- Configurable event retention period (1-400 days, default 14)
- Automatic SharpCap sequence generation with customizable templates
- Customizable per-event settings (exposure, gain, recording duration)
- **Observation Preparation Panel**: Integrated workflow for setting up events
  - Load event for preparation with summary display
  - GOTO mount control with automatic slewing
  - Plate solve verification and target labeling
  - Camera setup with exposure and coordinate configuration
  - Test recording with automatic settings preservation and restoration

**SharpCap Sequence Generation**
- Full control over recording workflow through customizable templates
- Automated mount control, camera configuration, and recording
- Flexible templates for any equipment setup or recording style
- Support for unattended multi-event observation sessions
- Built-in templates: Full automation, minimal setup, and test recording
- Sequences use calculated or custom exposure, gain, and duration values

**Report Generation (Experimental)**
- ⚠️ **Under Development**: Report generation has not been approved by NA or TT reporting coordinators
- Single comprehensive dialog for workflow efficiency
- Integrates AOTA timing data and Tangra CSV analysis
- Supports North America (IOTA) and Trans-Tasman (RASNZ) formats
- Use with caution and verify all generated data before submission

**Equipment Management**
- Multiple telescope and camera configurations
- Active equipment selection
- Equipment details automatically populate reports

## Benefits

1. **Complete Control**: SharpCap sequences give you full flexibility over your recording workflow
2. **Customizable Automation**: Automate as little or as much as needed for your setup
3. **Equipment Flexibility**: Templates can be adapted to any telescope, mount, and camera combination
4. **Simplified Event Management**: No need for Occult Watcher Desktop for predictions
5. **Multi-Event Sessions**: Generate sequences for entire night's observations
6. **Safe Testing**: Test recordings preserve your camera settings automatically

## Workflow

1. **Download Events**: Sync with Occult Watcher Cloud to get your announced stations
2. **Prepare for Observation**: Use the Observation Preparation panel to set up for your event
   - **Load Event**: Select an event from the grid to prepare
   - **GOTO**: Automatically slew your mount to the event coordinates
   - **Plate Solve**: Verify pointing and label the target star
   - **Setup**: Configure SharpCap camera settings (exposure, coordinates)
   - **Test Recording**: Make a short test recording to verify setup without disrupting your settings
3. **Customize Settings**: Override calculated exposure, gain, or recording duration if needed
4. **Generate Sequences**: Create customized SharpCap sequences for automated recording
5. **Record Event**: Run the sequence to capture the occultation with full control
6. **Analyze in Tangra**: Process video to generate light curve CSV and timing data
7. **(Optional) Generate Reports**: Experimental feature for Excel reports - verify all data before submission

## Installation
## Installation

1. Download the Python code from **occultation-manager.zip** above by right clicking and selecting 'Save As'
2. Unzip to a file location where you have read/write access. Suggest a new subfolder \Documents\SharpCap\occultation-manager
3. Alternative: clone this GitHub repository if you are a GitHub user
4. Start SharpCap
5. In "File" → "SharpCap Settings" → "Startup Scripts" → find that folder and add the 'main' script

<img width="666" height="155" alt="image" src="https://github.com/user-attachments/assets/42a9d9c9-4273-4a88-8d0a-428cca649afe" />

6. Close SharpCap (the script will be loaded at the next start)

A new button should appear in the SharpCap main toolbar. Press it to start the Occultation Manager.
<img width="117" height="28" alt="image" src="https://github.com/user-attachments/assets/6dbdf7af-aea5-4637-a39a-ff8a435dce55" />

## Configuration Setup

Press the  Occultations button in SharpCap to start the Occultation Manager.

Setup your Occult Watcher Cloud configuration. Go to the **Tools | Configuration** menu, **Credentials** Tab and follow the instructions there. You will need an OWC account and API key.

Under the **File Paths** tab you can set file paths and file names. Default values should be fine but you might want to use a different folder for your Sequences. You can also configure the event retention period (1-400 days, default 14) which determines how long past events remain in your list.

Under **User Settings** set it up to suit your telescope. Each setting has an **Explain** button that provides detailed information, formulas, and examples. You can also set the default camera gain (0-600, default 450) which will be used for new events.

Save the configuration.

## SharpCap Sequences - Your Recording Workflow

The Occultation Manager generates SharpCap Sequences that give you complete control over your recording workflow. By using sequences, you can customize the automation to match your equipment, observing style, and comfort level. **You have full flexibility to automate everything or just the essentials.**

### Why Use Sequences?

- **Complete Control**: You decide what gets automated and what stays manual
- **Equipment Specific**: Adapt to your exact telescope, mount, camera, and accessories
- **Safety First**: Control mount movements, pointing, and post-observation positioning
- **Multi-Event Capable**: Generate a single sequence for an entire night's observations
- **Reliable**: Test and refine your templates before relying on them

## Sequencer Templates
The Occultation Manager is used to generate SharpCap Sequences, and these sequences are used to run the events. By using SharpCap Sequences the user can customise the event recording to their system and to what they need to do. So you can do anything that a SharpCap Sequence can do and automate as little or as much as you want. You can generate a single sequence that will run an entire nights observations.

### Template Variables
Templates use Python string formatting with the following variables from each event:
- **{exposure}**: Exposure time in seconds (calculated or custom override)
- **{gain}**: Camera gain 0-600 (default 450 or custom override)
- **{recording_duration}**: Total recording duration in seconds (calculated or custom override)
- Additional variables: start/end times, coordinates, event details

### Provided Templates

Five templates are included demonstrating different automation levels and timing approaches:

**⭐ SharpCap Sequence UTC Template** (RECOMMENDED - Full Automation with UTC Timing):
- **Best and safest template** with proper UTC-based countdown system
- Handles times safely regardless of when started (late start, next day, after midnight)
- User can safely stop and restart countdown without missing events
- Fully configures mount and camera for each observation
- Sets binning, ROI, file format, exposure, gain, and recording settings
- Automated GOTO, plate solve, and safe finish positioning
- Parks mount in safe position after each observation
- Suitable for unattended multi-night operation
- Uses Python code for accurate UTC countdown calculations

**SharpCap Sequence Local Time Template** (Full Automation with Local Time):
- ⚠️ **Less safe**: Has problems with times after local midnight
- ⚠️ **Cannot handle next day events**: Only works for current night observations
- Fully configures mount and camera like UTC template
- Requires manual "WAIT UNTIL" statements to prevent premature start
- Risk of missing events if local time crosses midnight
- Must add 86400 second delays for each day's wait, or use UTC template instead

**SharpCap Minimal Local Time Template** (Basic Automation):
- ⚠️ **Same local time risks** as above (midnight issues, current night only)
- Assumes you've manually configured most camera recording settings
- Automated GOTO and plate solve
- Only adjusts exposure and gain for each event
- Minimal automation for those wanting more manual control

**SharpCap Just Record Template** (Manual Setup):
- Bare bones recording only - no GOTO, no plate solve, no camera setup
- Uses local time for recording start (same midnight risks)
- Assumes user has already pointed telescope and configured camera
- Intended for ad-hoc interactive use
- Only sets target name and triggers recording at event time

**SharpCap Test Recording Template** (Verification):
- Immediate short recording for pre-event testing (no waiting)
- Used automatically by the **Test Recording** button
- Verifies focus, framing, and camera settings
- Automatically restores camera settings after test
- Configures binning, ROI, format, exposure, and gain for test

### Critical: Test and Customize

⚠️ **You MUST test and adapt these templates to your specific setup before using them for observations.** The provided templates are examples only.

**Before relying on any template:**
- Test extensively during daytime with your actual equipment
- Verify all mount movements are safe and correct
- Check that camera settings match your requirements
- Ensure file paths and formats work with your system
- Test unattended operation thoroughly before trusting it
- Consider cable management and equipment safety
- Plan for post-sunrise mount positioning

**Safety Considerations:**
- Risk of equipment damage from cable snags or incorrect pointing
- Risk of sun exposure if sequence runs past sunrise
- Risk of failed observations due to untested settings
- Unattended operation requires extensive testing and safety planning

## Event Customization

The Occultation Manager automatically calculates optimal exposure times and recording durations for each event based on the predicted magnitude drop and event duration. However, you can override these defaults for specific events:

### Edit Settings Dialog
Double-click on an event's Exposure, Gain, or Recording Time column (or use the **Edit Settings** toolbar button) to customize:

**Exposure Time (1-10000 ms)**
- Calculated from predicted magnitude drop (brighter drops = shorter exposure)
- Override for specific camera sensitivity or event characteristics
- Quick buttons: 40, 80, 120, 160, 200, 240, 320, 480 ms

**Gain (0-600)**
- Default value configurable in Tools → Configuration → User Settings
- Standard default: 450
- Override for specific camera or event requirements
- Quick buttons: 200, 250, 300, 350, 450, 550

**Recording Duration (10-3600 seconds)**
- Calculated as: (uncertainty × 8) + (max_duration × 2)
- Override for specific event timing requirements
- Quick buttons: 30, 60, 90, 120, 180, 300 seconds

### Custom Value Indicators
The event grid displays an asterisk (*) next to values that have been customized:
- **Exposure (ms)*** - Custom exposure time
- **Gain*** - Custom gain value
- **Recording Time (s)*** - Custom recording duration

### Reset to Defaults
Use the Reset button in the Edit Settings dialog to restore calculated values. The system intelligently detects when custom values match calculated defaults and removes the custom flag automatically.

## Observation Preparation

The Observation Preparation panel provides an integrated workflow for setting up and testing your observation before the actual event. Select exactly one event from the grid to use these features:

### Load Event
Loads the selected event into the preparation panel, displaying key information:
- Asteroid name and event time (UTC)
- Altitude and azimuth coordinates
- Exposure time (calculated or custom)
- Maximum event duration
- Star magnitude

### GOTO
Automatically slews your telescope mount to the event coordinates. Requires SharpCap integration with your mount software (ASCOM, etc.).

### Plate Solve
Performs plate solving to:
- Verify mount pointing accuracy
- Calculate offset from target coordinates
- Label the target star in the field of view

Use this after GOTO to confirm your telescope is correctly positioned.

### Setup
Configures SharpCap camera settings for the event:
- Sets the exposure time to the calculated/custom value
- Copies event coordinates (RA/Dec) to clipboard for manual entry if needed
- Prepares camera for the observation

### Test Recording
Makes a short test recording to verify your setup without disrupting your carefully configured camera settings. The test recording:

**What it does:**
1. Saves your current camera settings (binning, exposure, gain, resolution, display levels)
2. Runs a short recording sequence using the "SharpCap Test Recording Template.txt"
3. Automatically restores all camera settings after recording completes
4. Waits for camera stabilization (2× exposure time)
5. Restores display stretch levels to match your pre-test view

**Why use it:**
- Verify focus and framing before the event
- Test your camera setup without manual adjustment afterwards
- Ensure recording settings work correctly
- Check field of view and target visibility
- Confirm no issues with the sequence template

**Settings Preserved:**
- Camera binning
- Exposure time
- Gain value
- Resolution/ROI
- Display black/mid/white levels (stretch)

**Template Required:**
The test recording feature requires a template file named "SharpCap Test Recording Template.txt" in your configured templates folder. This template should define a brief recording sequence (typically 10-30 seconds) suitable for testing purposes.

## Report Generation (Experimental)

⚠️ **Important Warning**: Report generation is still under development and has not been approved by the North America or Trans-Tasman reporting coordinators. Use with caution and carefully verify all generated data before submission to any reporting organization.

Reports are generated using a streamlined single-dialog workflow that combines:
- Report format selection (North America / Trans-Tasman)
- Telescope and camera selection
- Observation type (Positive / Negative / Unsure)
- AOTA file selection (.aota.xml OR .txt for D/R times and SNR)
- Tangra CSV file selection (light curve with timing data)

### Supported Report Formats
- **North America (IOTA V5.6.12r)**: IOTA standard report form
- **Trans-Tasman (RASNZ V4.1.2.G)**: Australia/New Zealand report form
- **SODIS Europe**: Planned for future implementation

### Timing Data Integration

**From AOTA Files (.aota.xml or AOTA_Report.txt)**:
- Disappearance (D) time with uncertainty (±error in seconds)
- Reappearance (R) time with uncertainty (±error in seconds)
- Signal-to-Noise Ratio (SNR) from AOTA Report text files
- Event quality indicators
- Either file type accepted (XML or text report)
- Automatic time comparison when both files provided (warns if times differ by >0.1s)

**From Tangra CSV Files**:
- Observation start time (HH:MM:SS.SS)
- Observation end time (HH:MM:SS.SS)
- Exposure time in seconds (3 decimal places)
- Camera acquisition delay in seconds (from measurement parameters table)

### Workflow Improvements
- **Settings Persistence**: Remembers last report type and folder location
- **Auto-Selection**: Automatically selects first available AOTA and Tangra files
- **Smart Validation**: AOTA file (XML or Report) required for Positive/Unsure observations, optional for Negative
- **Flexible Timing**: Accepts either AOTA.xml OR AOTA_Report.txt (or both for validation)
- **Time Verification**: Compares D/R times when both AOTA sources provided
- **Multi-Event Support**: Select specific event from AOTA Reports with multiple events
- **One-Click Generation**: Single dialog replaces 5 separate dialogs

### File Organization
For efficient workflow, organize files in folders by event:
```
D:\Occultations\Reported\20251107 (778) Theobalda+\
  ├── event.aota.xml          # AOTA XML timing file (optional)
  ├── event_AOTA_Report.txt   # AOTA text report with D/R times and SNR (optional)
  ├── light_curve.csv         # Tangra CSV
  └── video.ser              # Original recording
```

**Note**: You need either `event.aota.xml` OR `event_AOTA_Report.txt` (or both for cross-validation) for Positive/Unsure observations.

The dialog remembers the parent folder (e.g., `D:\Occultations\Reported\`) making it easy to switch between event folders.
